def reference(df):
    mask = df["id"].astype(str).str.match(r"^[0-9]{1,20}$")
    return float(df.loc[mask, "amount"].sum())
