def reference(df):
    return int(df["score"].isna().sum())
