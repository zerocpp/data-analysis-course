import pandas as pd
from decimal import Decimal, ROUND_HALF_UP


def reference(df):
    total = sum(
        Decimal(str(value)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
        for value in df['amount']
    )
    return float(total)
