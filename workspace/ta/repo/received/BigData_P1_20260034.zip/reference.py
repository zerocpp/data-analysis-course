def reference(df):
    mask = (
        df["region"].isin(["East", "North"])
        & (df["status"] == "completed")
        & (df["amount"] >= 200)
        & (df["returned"] == "No")
    )
    return int(mask.sum())
