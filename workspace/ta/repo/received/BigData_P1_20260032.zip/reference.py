def reference(df):
    g = df.groupby("rep_id", as_index=False).agg(total_sales=("sales", "sum"), total_returns=("returns", "sum"))
    g = g.sort_values(["total_sales", "total_returns", "rep_id"], ascending=[False, True, True])
    return g.iloc[0]["rep_id"]
