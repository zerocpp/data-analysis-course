def reference(df):
    customers = (
        df.loc[df["record_type"] == "customer", ["entity_id"]]
          .rename(columns={"entity_id": "customer_id"})
    )
    orders = df.loc[df["record_type"] == "order", ["customer_id", "amount"]]
    merged = orders.merge(customers, on="customer_id", how="inner")
    return int(merged["amount"].sum())
