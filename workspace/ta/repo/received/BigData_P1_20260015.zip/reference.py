def reference(df):
    return df.groupby("department")["score"].mean().idxmax()
