def reference(df):
    return float(df.loc[df["status"] == "ok", "amount"].sum())
