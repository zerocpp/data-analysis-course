def reference(df):
    month = df["date"].str.slice(5, 7).astype(int)
    flag = df["flag"].map({"YES": True, "NO": False})
    return float(df.loc[flag & (month == 2), "value"].sum())
