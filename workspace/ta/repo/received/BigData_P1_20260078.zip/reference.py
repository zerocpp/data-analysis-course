import pandas as pd

def reference(df):
    x = df.copy()
    x["date"] = pd.to_datetime(x["date"])
    x = x.loc[
        (x["date"] >= "2026-04-01")
        & (x["date"] < "2026-07-01")
        & (x["status"] == "completed")
        & (x["returned"] == "No")
    ].copy()
    x["net_revenue"] = x["price"] * x["quantity"] * (100 - x["discount_pct"]) / 100
    rg = x.groupby("region", as_index=False)["net_revenue"].sum().sort_values(["net_revenue", "region"], ascending=[False, True])
    best_region = rg.iloc[0]["region"]
    ch = x.loc[x["region"] == best_region].groupby("channel", as_index=False)["net_revenue"].sum().sort_values(["net_revenue", "channel"], ascending=[False, True])
    best_channel = ch.iloc[0]["channel"]
    return f"{best_region}|{best_channel}"
