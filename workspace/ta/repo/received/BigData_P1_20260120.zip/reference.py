def reference(df):
    for col in ["student_id", "name", "score"]:
        if df[col].notna().all() and df[col].is_unique:
            return col
    return "none"
