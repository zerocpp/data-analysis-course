def reference(df):
    def f1(col):
        tp = int(((df["y_true"] == 1) & (df[col] == 1)).sum())
        fp = int(((df["y_true"] == 0) & (df[col] == 1)).sum())
        fn = int(((df["y_true"] == 1) & (df[col] == 0)).sum())
        precision = tp / (tp + fp) if (tp + fp) else 0.0
        recall = tp / (tp + fn) if (tp + fn) else 0.0
        return 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
    a, b = f1("pred_A"), f1("pred_B")
    return "pred_A" if a >= b else "pred_B"
