def reference(df):
    candidates = ["order_id", "customer_id", "product_code", "warehouse", "batch_no"]
    for col in candidates:
        if df[col].notna().all() and df[col].is_unique:
            return col
    return "none"
