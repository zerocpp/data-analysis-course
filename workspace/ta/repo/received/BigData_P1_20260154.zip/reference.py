import pandas as pd

def reference(df):
    x = df.loc[df["status"] == "completed"].copy()
    x["date"] = pd.to_datetime(x["date"])
    first = x.groupby("customer_id")["date"].transform("min")
    mask = (x["date"] >= first) & (x["date"] < first + pd.Timedelta(days=7))
    return int(x.loc[mask, "sales"].sum())
