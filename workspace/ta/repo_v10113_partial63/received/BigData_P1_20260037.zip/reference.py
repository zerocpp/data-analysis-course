def reference(df):
    return int((df["score"] >= 80).sum())
