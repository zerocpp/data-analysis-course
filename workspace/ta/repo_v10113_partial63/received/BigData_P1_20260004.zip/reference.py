def reference(df):
    x = df.loc[(df["status"] == "active") & df["score"].notna()].copy()
    x["weighted"] = x["score"] * x["weight"]
    g = x.groupby("department", as_index=False).agg(weighted_sum=("weighted", "sum"), weight_sum=("weight", "sum"))
    g["weighted_avg"] = g["weighted_sum"] / g["weight_sum"]
    g = g.sort_values(["weighted_avg", "department"], ascending=[False, True])
    return g.iloc[0]["department"]
