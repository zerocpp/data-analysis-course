def reference(df):
    return df.sort_values("score", ascending=False).iloc[0]["student_id"]
