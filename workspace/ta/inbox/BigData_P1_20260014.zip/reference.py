def reference(df):
    x = df.loc[df["status"] == "completed"].copy()
    x["net_revenue"] = (
        x["unit_price"] * x["quantity"] * (100 - x["discount_pct"]) / 100
        + x["shipping_fee"]
    )
    return int(round(x["net_revenue"].sum()))
