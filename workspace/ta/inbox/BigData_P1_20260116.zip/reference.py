def reference(df):
    t = df.sort_values(["amount", "order_id"]).drop_duplicates("order_id", keep="first")
    return float(t.head(3)["amount"].sum())
