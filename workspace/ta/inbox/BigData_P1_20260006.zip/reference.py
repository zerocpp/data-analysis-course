def reference(df):
    acc = (df["y_true"] == df["y_pred"]).mean()
    return f"{acc:.2f}"
