def reference(df):
    return float(df["amount"].str.replace(",", "", regex=False).str.strip().astype(float).sum())
