def reference(df):
    customers = (
        df.loc[(df["record_type"] == "customer") & (df["status"] == "active"), ["entity_id"]]
        .rename(columns={"entity_id": "customer_id"})
    )
    orders = df.loc[
        (df["record_type"] == "order") & (df["status"] == "completed"),
        ["order_id", "customer_id", "amount"],
    ].copy()
    orders = orders.merge(customers, on="customer_id", how="inner")
    refunds = df.loc[
        (df["record_type"] == "refund") & (df["status"] == "approved"),
        ["order_id", "amount"],
    ].rename(columns={"amount": "refund_amount"})
    refunds = refunds.groupby("order_id", as_index=False)["refund_amount"].sum()
    merged = orders.merge(refunds, on="order_id", how="left")
    merged["refund_amount"] = merged["refund_amount"].fillna(0)
    return int((merged["amount"] - merged["refund_amount"]).sum())
