def reference(df):
    diff = (df["sales"] - df["refunds"] - df["net"]).abs()
    return int((diff > 1e-6).sum())
