import pandas as pd

def reference(df):
    s = df["score_raw"].astype("string").str.strip()
    numeric = pd.to_numeric(s, errors="coerce")
    return int(numeric.isna().sum())
