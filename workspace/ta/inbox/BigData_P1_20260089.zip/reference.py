def reference(df):
    cols = ["feature_a", "feature_b", "feature_c"]
    vals = {c: abs(df[["target", c]].dropna()["target"].corr(df[["target", c]].dropna()[c])) for c in cols}
    return sorted(cols, key=lambda c: (-vals[c], c))[0]
