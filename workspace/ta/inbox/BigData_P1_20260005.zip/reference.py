def reference(df):
    return f'{df["x"].corr(df["y"]):.2f}'
