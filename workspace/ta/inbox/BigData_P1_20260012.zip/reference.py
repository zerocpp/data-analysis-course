def reference(df):
    return int((df["price"] * df["quantity"]).sum())
