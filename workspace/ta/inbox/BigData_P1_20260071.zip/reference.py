import pandas as pd


def reference(df):
    deduped = df.drop_duplicates()
    return int(deduped['amount'].sum())
