def reference(df):
    x = df.loc[df["region"] == "East"].copy()
    x["revenue"] = x["price"] * x["quantity"]
    return int(x["revenue"].sum())
