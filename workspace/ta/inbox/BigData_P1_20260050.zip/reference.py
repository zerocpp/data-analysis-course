def reference(df):
    bad = int((df["reported_total"] != df["amount"]).sum())
    total = float(df["amount"].sum())
    return f"{bad},{total}"
