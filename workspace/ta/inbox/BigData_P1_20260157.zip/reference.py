import pandas as pd

def reference(df):
    x = df.copy()
    x["date"] = pd.to_datetime(x["date"])
    mask = (x["date"] >= "2026-03-01") & (x["date"] < "2026-04-01")
    return int(x.loc[mask, "sales"].sum())
