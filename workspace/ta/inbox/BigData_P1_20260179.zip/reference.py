def reference(df):
    mean_value = df["value"].mean()
    return int((df["value"] > mean_value).sum())
