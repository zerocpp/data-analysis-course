def reference(df):
    mask = (df["region"] == "east") & (df["amount"] >= 30) & (df["amount"] < 100) \
        & df["category"].isin(["A", "B"])
    return int(mask.sum())
